<html lang="pt">
<head>
    <title>Sistema de login simples d+</title>
</head>
<body>
<h1>Entre aqui para ser admin do site :D</h1>
<form action="admin.php" method="post">
    <input name="nome" type="text" placeholder="Entre aqui com o seu nome">
    <input name="senha" type="password" placeholder="Entre aqui com sua senha">
    <input type="submit" value="Entrar">
</form>
</body>
</html>